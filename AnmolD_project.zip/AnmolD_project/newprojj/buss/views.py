from django.shortcuts import render,redirect
from .models import Route
from .forms import FareCalculationForm
from .models import BusDepot, Bus
from .forms import DepotForm
from .utils import get_geocode  
import requests
import json
from django.http import JsonResponse
from .forms import PassForm
from .models import Pass
# Create your views here.



def calculate_fare(request):
    fare = None
    form = FareCalculationForm(request.POST or None)
    
    if request.method == 'POST' and form.is_valid():
        source = form.cleaned_data['source']
        destination = form.cleaned_data['destination']
        
        # Query the database for the fare
        try:
            route = Route.objects.get(source=source, destination=destination)
            fare = route.fare
        except Route.DoesNotExist:
            fare = "Fare not available for the given route"
    
    return render(request, 'fare_calculator.html', {
        'form': form,
        'fare': fare,
    })



def aboutview(request):
    
    return render(request,'about.html')



def depot_timings(request):
    if request.method == 'POST':
        form = DepotForm(request.POST)
        if form.is_valid():
            depot_name = form.cleaned_data['depot_name']
            try:
                depot = BusDepot.objects.get(name=depot_name)
                buses = Bus.objects.filter(depot=depot)
                context = {'buses': buses, 'depot_name': depot_name}
            except BusDepot.DoesNotExist:
                context = {'error': 'Depot not found', 'form': form}
        else:
            context = {'form': form}
    else:
        form = DepotForm()
        context = {'form': form}

    return render(request, 'depot_timings.html', context)




def map_view(request):
    # Print the paths where Django is looking for templates
    try:
        template_paths = get_template('mapppp.html').name
        print(f"Template paths: {template_paths}")
    except Exception as e:
        print(f"Error: {e}")

    # Example data; replace with actual data fetching and processing
    geocode_data = {
        "results": [
            {
                "geometry": {
                    "location": {"lat": 40.730610, "lng": -73.935242}
                }
            }
        ]
    }
    geocode_data_json = json.dumps(geocode_data)
    return render(request, 'mapppp.html', {'geocode_data': geocode_data_json})






def get_geocode(address):
    api_key = 'AIzaSyAICCfqkhKRe6XiXmFwiDclq2dA9_bXLOE'
    url = 'https://maps.googleapis.com/maps/api/geocode/json'
    params = {'address': address, 'key': api_key}
    response = requests.get(url, params=params)
    return response.json()





def generate_pass(request):
    if request.method == 'POST':
        form = PassForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('pass_list')
    else:
        form = PassForm()
    return render(request, 'passes/generate_pass.html', {'form': form})

def pass_list(request):
    passes = Pass.objects.all()
    return render(request, 'passes/pass_list.html', {'passes': passes})




def pss(request):
    return render(request,'index1.html')



def cmpln(request):
    return render(request,'complain.html')


def bssc(request):
    return render(request,'index2.html')


